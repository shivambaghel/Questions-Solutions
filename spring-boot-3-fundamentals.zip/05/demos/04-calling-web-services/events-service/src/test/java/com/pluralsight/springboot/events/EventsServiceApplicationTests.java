package com.pluralsight.springboot.events;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventsServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
