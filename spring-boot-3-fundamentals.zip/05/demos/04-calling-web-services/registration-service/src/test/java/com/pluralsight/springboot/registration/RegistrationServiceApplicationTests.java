package com.pluralsight.springboot.registration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistrationServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
