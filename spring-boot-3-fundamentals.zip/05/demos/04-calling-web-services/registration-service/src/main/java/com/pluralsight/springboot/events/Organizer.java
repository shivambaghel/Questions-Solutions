package com.pluralsight.springboot.events;

public record Organizer(
        int id,
        String name,
        String description) {
}
